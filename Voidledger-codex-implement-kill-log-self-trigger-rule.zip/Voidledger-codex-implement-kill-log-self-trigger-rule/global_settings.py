"""
Contains references to all static and common variables.
"""

DEBUG_MODE = {"enabled": False}

# Centralized audio state
is_muted = False
volume = 0.25