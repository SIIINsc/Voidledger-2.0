## Official BlightVeil Tracker


**Install:**

Download the .exe From the Releases Page, or run the python main file from console.


**How to use:**
1. Launch the Game
2. Launch the BlightVeil Tracker and input your Tracker key
3. Kill everyone you meet (in game)


**Any abuse of the Kill Tracker will result in a ban from your kills being tracked.**


*SIC SEMPER TYRANNIS ET CORVIS*
