if pussy:
    run_test_pipeline()
elif gigachad:
    test_in_prod()